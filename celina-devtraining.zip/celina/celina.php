<?php
    if (isset($_POST['login'])) {
        $conn = new mysqli('localhost', 'root', '', 'devtraining');
        $ema = $conn->real_escape_string($_POST['emailphp']);
        $pwd = md5($conn->real_escape_string($_POST['pwordphp']));

       

        // $data = $conn->query(query: "SELECT id FROM userinfo WHERE email='$email' AND password='$pword'");


        $query = "SELECT * FROM userinfo WHERE email='$ema' AND password='$pwd'";
        $res = mysqli_query($conn, $query);
        $rowcount= mysqli_num_rows($res);

            if ($rowcount > 0) {
                exit ('<font color="green">This account exists.');                                                
            }
            else {
                exit ('<font color="red" class="d-flex justify-content-center">This account does not exist.');
            }
        } 
?>


<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   
    <title>celina (php/jquery)</title>
</head>
<body>
    <h1 class="d-flex justify-content-center"> celina (dev training: php & jquery) </h1>
    <div class="wrap d-flex justify-content-center">

        <form method="post" action="phpjquery.php" class="form-box">
            <input type="text" class="form-control" id="emailid" placeholder="email...">
            <input type="password" class="form-control" id="pwordid" placeholder="password...">
            <input type="button" id="loginid" class="btn btn-primary" value="Log In!">
        </form>
    </div>

    <h5 id="response" class="d-flex justify-content-center"></h5>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#loginid").on('click', function () {
                var varemail=$("#emailid").val();
                var varpword=$("#pwordid").val();

                if (varemail=="")
                    alert('Please input your email.');
                else if (varpword=="")
                    alert('Please input your password.');
                else if (varemail =="" && varpword=="")
                    alert('Please check your inputs.');
                else {
                    $.ajax(
                        {
                            url: 'celina.php',
                            method: 'POST',
                            data: {
                                login: 1,
                                emailphp: varemail,
                                pwordphp: varpword
                        },
                        success: function (response) {
                            // console.log(response);
                            $("#response").html(response);
                        },
                        dataType: 'text'
                    });

                }

            });
        });
    </script>

</body>
</html>